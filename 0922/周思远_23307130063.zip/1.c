#include<stdio.h>

int main(){
    char c;
    c=getchar();
    putchar(c);
    putchar('\n');
    return 0;
}