#include<stdio.h>
int main(){
    int a[ ]={1,3,5,7,9};
    float b;
    printf("%d\n",sizeof b);
    printf("%d\n",sizeof a/sizeof(int));
    return 0;
}

